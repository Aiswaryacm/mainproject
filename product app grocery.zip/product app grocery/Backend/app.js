const express = require('express');
const Productdata = require('./src/models/Productdata');
// const Logindata = require('./src/models/Logindata');
const Signupdata = require('./src/models/Signupdata');
var router = express.Router();
const cors= require('cors');
var bodyparser=require('body-parser');

var app= new express();
app.use(cors());
app.use(bodyparser.json())
app.get('/products',function(req,res){
    res.header("Access-Control-Allow-Origin","*")
    res.header("Access-Control-Allow-Method:GET,POST,DELETE,PATCH,PUT,OPTIONS");

Productdata.find()
.then(function(products){
    res.send(products);
});
});
app.post('/insert',function(req,res){
    res.header("Access-Control-Allow-Origin","*")
    res.header("Access-Control-Allow-Method:GET,POST,DELETE,PATCH,PUT,OPTIONS");
console.log(req.body);
var product={
    productId:req.body.product.productId,
    productName:req.body.product.productName,
    productCode:req.body.product.productCode,
    releaseDate:req.body.product.releaseDate,
    description:req.body.product.description,
    price:req.body.product.price,
    starRating:req.body.product.starRating,
    imageUrl:req.body.product.imageUrl
    
}
var product = new Productdata(product);
product.save();

});
// app.get('/login',function(req,res){
//     res.header("Access-Control-Allow-Origin","*")
//     res.header("Access-Control-Allow-Method:GET,POST,DELETE,PATCH,PUT,OPTIONS");

// Logindata.find()
// .then(function(login){
//     res.send(login);
// });
// });
app.post('/login',function(req,res){
    res.header("Access-Control-Allow-Origin","*")
    res.header("Access-Control-Allow-Method:GET,POST,DELETE,PATCH,PUT,OPTIONS");
    console.log(req.body,"in backend login");
    var email= req.body.login.email;
    var password =req.body.login.password;
 
        Signupdata.findOne({email:email,password:password},function(err,match){
                  if(err)
                  {
                   console.log("not valid")
                  }
                  else
                  {
                    if(!match)
                    {
                  res.status(401).send('Invalid mail')
                      
                    }
                    else
                    {
                     if(password!=match.password)
                     {
                        res.status(401).send('Invalid password')
                     }
                     else
                    {
                        res.send(match);
                      
                    }
                    }
                    
                  }
                  
                })
              
              
              
          });
            
        
//     var login= new Logindata(login);
// login.save();







    app.delete('/delete/:id',(req,res)=>{
        res.header("Access-Control-Allow-Origin","*")
    res.header("Access-Control-Allow-Method:GET,POST,DELETE,PATCH,PUT,OPTIONS");
console.log(req.params.id);

        Productdata.findOneAndDelete(req.params.id,(err,doc)=>{
if(!err){res.send(doc);}
else {console.log('err in product delete');}


        })

    })

    app.get('/signup',function(req,res){
        res.header("Access-Control-Allow-Origin","*")
        res.header("Access-Control-Allow-Method:GET,POST,DELETE,PATCH,PUT,OPTIONS");
    Signupdata.find()
    .then(function(signup){
        res.send(signup);
    });
    });
    app.post("/signup",function(req,res){                      
        res.header("Access-Control-Allow-Origin","*")
        res.header("Access-Control-Allow-Method:GET,POST,DELETE,PATCH,PUT,OPTIONS");
        var signup = {
     
          
          username:req.body.signup.username,
          phonenumber:req.body.signup.phonenumber,
          email:req.body.signup.email,
          password:req.body.signup.password
   
        }
    console.log("req.body.username"+req.body.signup.username);
        var signup= new Signupdata(signup);
              signup.save((data)=>{
                  res.send(data)
              });                    
                      
    });

    app.post('/update',function(req,res){
        res.header("Access-Control-Allow-Origin","*");
        res.header('Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS');
        console.log(req.body);
    
    var product ={
        productId : req.body.product.productId,
        productName : req.body.product.productName,
        productCode : req.body.product.productCode,
        releaseDate : req.body.product.releaseDate,
        description : req.body.product.description,
        price : req.body.product.price,
        starRating : req.body.product.starRating,
        imageUrl : req.body.product.imageUrl
    
    }
    console.log("Data got in server in edit " +product._id);
    ProductData.updateOne(
        {_id:req.body.productItem._id},{$set:product},
         function(err,res){
         if(err){
             console.log(err)
            }
        }
         )
         
    });


    
    app.listen(3000,function(){
console.log('listening to port 3000');
    });
module.exports = router;