import { Component, OnInit } from '@angular/core';
import {AuthService} from '../auth.service';
import { Router } from '@angular/router';
import {loginModel} from './login.model'
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  title:String="Login";

  
  constructor(private authservice:AuthService,private router:Router) { }
  loginUserData= new loginModel(null,null);
  ngOnInit(): void {
  }
  loginUser(){
    console.log("logincomponent"+this.loginUserData);
    this.authservice.loginUser(this.loginUserData)
    .subscribe(
      (data)=>{
        this.router.navigate(['/products']);
     })
    
    
    }
}
