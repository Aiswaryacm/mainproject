export class loginModel{
    constructor(
    public email:String,
    public password:String
    ){}

}