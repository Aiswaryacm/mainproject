import { Injectable } from '@angular/core';
import  {HttpClient} from '@angular/common/http';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class AuthService {
private _singupUrl="http://localhost:3000/signup"
  constructor(private http:HttpClient, private router: Router) { }
  signupUser(item){ console.log('item',item)
    return this.http.post("http://localhost:3000/signup",{"signup":item})
    
  }
  loginUser(item){ console.log('item',item)
    return this.http.post("http://localhost:3000/login",{"login":item})
    
    
}loggedIn(){
  return !!localStorage.getItem('token')
}
logoutUser(){
  localStorage.removeItem('token')
  this.router.navigate(['/'])
}
}
