import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductListComponent } from './product-list/product-list.component';
import { NewProductComponent } from './new-product/new-product.component';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { UpdateProductComponent } from './update-product/update-product.component';
import { IndexComponent } from './index/index.component';


const routes: Routes = [
{path:'',component:LoginComponent},
{path:'products',component:ProductListComponent},
{path:'add',component:NewProductComponent},
{path:'signup',component:SignupComponent},
{path:'update',component:UpdateProductComponent},
{path:'login',component:ProductListComponent},
{path:'index',component:IndexComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
