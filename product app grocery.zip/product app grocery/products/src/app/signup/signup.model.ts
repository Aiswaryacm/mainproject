export class signupModel{
    constructor(
    public username:String,
    public phonenumber:Number,
    public email:String,
    public password:String
    ){}

}