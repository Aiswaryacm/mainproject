import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {ProductModel} from '../product-list/product.model';
import {ProductService} from '../product.service';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.css']
})
export class IndexComponent implements OnInit {
  
 title:String="Add to cart";
  constructor(private productService:ProductService,private router:Router) { }
  productItem= new ProductModel(null,null,null,null,null,null,null,null);
  ngOnInit(): void {
  }
 
  
  BuyProduct(){
    this.productService.postBook(this.productItem);
    console.log('called');
    alert('success');
    this.router.navigate(['/products']);
  }
  
}
